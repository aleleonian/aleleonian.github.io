const { Builder, By, until } = require('selenium-webdriver');

(async function () {

    let driver = await new Builder()
        .forBrowser('chrome')
        .build();

    try {

        await driver.get('https://aleleonian.github.io/click/index.html");

        driver.manage().window().maximize();

        await driver.findElement(By.id('humanBotButton')).click();

    }
    catch (error) {
        console.log("exception!->" + error);
    }
    finally {
        // driver.quit();
    }
})();