const {Builder} = require('selenium-webdriver');

const firefox = require('selenium-webdriver/firefox');

const url = "aleleonian.github.io/knock-headless/index.html";

(async function() {
    var driver = new Builder().forBrowser('firefox')
        .setFirefoxOptions(new firefox.Options().addArguments('--headless'))
        .build();
    try {
        await driver.get(url);


    } finally {
        await driver.quit();
    }
})();