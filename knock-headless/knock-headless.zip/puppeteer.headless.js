const puppeteer = require('puppeteer');

const url = "aleleonian.github.io/knock-headless/index.html";

var browser;

async function run() {

    try {
        browser = await puppeteer.launch({
            headless: true
        });
        const page = await browser.newPage();

        await page.goto(url)

    }

    catch (error) {
        console.log("theres an error!->" + error);
    }
    finally {
        await browser.close();
    }

}

run();